import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { supabase } from '../lib/supabaseClient'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null)
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)

  const loadProfile = useCallback(async (userId) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, phone, address, role, is_active')
      .eq('id', userId)
      .maybeSingle()
    if (error) {
      console.error('Failed to load profile', error.message)
      return null
    }
    setProfile(data)
    return data
  }, [])

  useEffect(() => {
    let mounted = true

    supabase.auth.getSession().then(async ({ data: { session: s } }) => {
      if (!mounted) return
      setSession(s)
      if (s?.user) {
        await loadProfile(s.user.id)
      }
      setLoading(false)
    })

    const { data: sub } = supabase.auth.onAuthStateChange((_event, s) => {
      ;(async () => {
        setSession(s)
        if (s?.user) {
          await loadProfile(s.user.id)
        } else {
          setProfile(null)
        }
        setLoading(false)
      })()
    })

    return () => {
      mounted = false
      sub.subscription.unsubscribe()
    }
  }, [loadProfile])

  const signIn = useCallback(async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password })
    if (error) throw error
    if (data.user) {
      const p = await loadProfile(data.user.id)
      return { session: data.session, profile: p }
    }
    return { session: data.session, profile: null }
  }, [loadProfile])

  const signUp = useCallback(async ({ full_name, email, password, phone, address }) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name } },
    })
    if (error) throw error

    if (data.user) {
      const { error: upErr } = await supabase
        .from('profiles')
        .update({ phone: phone || null, address: address || null, full_name })
        .eq('id', data.user.id)
      if (upErr) console.error('Profile update failed', upErr.message)
      await loadProfile(data.user.id)
    }
    return data
  }, [loadProfile])

  const signOut = useCallback(async () => {
    await supabase.auth.signOut()
    setSession(null)
    setProfile(null)
  }, [])

  const refreshProfile = useCallback(async () => {
    if (session?.user) await loadProfile(session.user.id)
  }, [session, loadProfile])

  const value = {
    session,
    profile,
    user: session?.user || null,
    role: profile?.role || null,
    isAuthenticated: !!session,
    loading,
    signIn,
    signUp,
    signOut,
    refreshProfile,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
