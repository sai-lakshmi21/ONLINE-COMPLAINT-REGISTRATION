import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { Spinner } from './Spinner'

const HOME_BY_ROLE = {
  user: '/user/dashboard',
  officer: '/officer/dashboard',
  admin: '/admin/dashboard',
}

export function ProtectedRoute({ children, roles }) {
  const { loading, isAuthenticated, role } = useAuth()
  const location = useLocation()

  if (loading) return <Spinner label="Checking your session…" />

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (roles && roles.length > 0 && !roles.includes(role)) {
    return <Navigate to={HOME_BY_ROLE[role] || '/'} replace />
  }

  return children
}

export function RedirectIfAuthed({ children }) {
  const { loading, isAuthenticated, role } = useAuth()
  if (loading) return <Spinner label="Checking your session…" />
  if (isAuthenticated) return <Navigate to={HOME_BY_ROLE[role] || '/'} replace />
  return children
}
