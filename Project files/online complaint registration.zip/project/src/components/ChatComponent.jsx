import { useState, useEffect, useRef } from 'react'
import { useAuth } from '../context/AuthContext'
import { getMessages, sendMessage, subscribeToMessages, unsubscribeChannel } from '../services/messageService'

function formatTime(iso) {
  if (!iso) return ''
  return new Date(iso).toLocaleString(undefined, { dateStyle: 'short', timeStyle: 'short' })
}

export function ChatComponent({ complaintId, canChat = true }) {
  const { user, profile } = useAuth()
  const [messages, setMessages] = useState([])
  const [text, setText] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const [connected, setConnected] = useState(false)
  const scrollRef = useRef(null)

  useEffect(() => {
    let active = true
    setLoading(true)
    getMessages(complaintId)
      .then((data) => {
        if (!active) return
        setMessages(data)
      })
      .catch((e) => setError(e.message))
      .finally(() => active && setLoading(false))

    const channel = subscribeToMessages(complaintId, (newMsg) => {
      setMessages((prev) => {
        if (prev.some((m) => m.id === newMsg.id)) return prev
        return [...prev, newMsg]
      })
      setConnected(true)
    })

    return () => {
      active = false
      unsubscribeChannel(channel)
    }
  }, [complaintId])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages])

  const handleSend = async (e) => {
    e.preventDefault()
    const trimmed = text.trim()
    if (!trimmed || sending) return
    setSending(true)
    const optimistic = {
      id: `tmp-${Date.now()}`,
      text: trimmed,
      created_at: new Date().toISOString(),
      sender_id: user.id,
      sender: { id: user.id, full_name: profile?.full_name, role: profile?.role },
      _pending: true,
    }
    setMessages((prev) => [...prev, optimistic])
    setText('')
    try {
      const saved = await sendMessage(complaintId, trimmed)
      setMessages((prev) => prev.map((m) => (m.id === optimistic.id ? saved : m)))
    } catch (err) {
      setMessages((prev) => prev.filter((m) => m.id !== optimistic.id))
      setError(err.message || 'Failed to send message.')
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="card card-shadow border-0 chat-card">
      <div className="card-header bg-white border-0 d-flex align-items-center justify-content-between py-3">
        <div>
          <h5 className="mb-0"><i className="bi bi-chat-dots me-2 text-primary" />Real-time Chat</h5>
          <small className="text-muted">Conversation between citizen and assigned officer.</small>
        </div>
        <span className={`badge rounded-pill ${connected ? 'text-bg-success' : 'text-bg-secondary'}`}>
          <span className="me-1">●</span>{connected ? 'Live' : 'Connecting…'}
        </span>
      </div>

      <div className="chat-body" ref={scrollRef}>
        {loading ? (
          <div className="text-center text-muted py-5">
            <div className="spinner-border spinner-border-sm me-2" />Loading messages…
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center text-muted py-5">
            <i className="bi bi-chat fs-3 d-block mb-2 opacity-50" />
            No messages yet. Start the conversation.
          </div>
        ) : (
          messages.map((m) => {
            const mine = m.sender_id === user.id
            const isOfficer = m.sender?.role === 'officer'
            const isAdmin = m.sender?.role === 'admin'
            return (
              <div key={m.id} className={`chat-msg ${mine ? 'mine' : 'theirs'}`}>
                <div className="chat-bubble">
                  <div className="chat-meta">
                    <strong>{m.sender?.full_name || 'Unknown'}</strong>
                    {isOfficer && <span className="badge text-bg-info ms-1">Officer</span>}
                    {isAdmin && <span className="badge text-bg-secondary ms-1">Admin</span>}
                  </div>
                  <div className="chat-text">{m.text}</div>
                  <div className="chat-time">{formatTime(m.created_at)}</div>
                </div>
              </div>
            )
          })
        )}
      </div>

      {canChat ? (
        <form onSubmit={handleSend} className="chat-input-bar">
          <input
            type="text"
            className="form-control"
            placeholder="Type a message…"
            value={text}
            onChange={(e) => setText(e.target.value)}
            disabled={sending}
          />
          <button type="submit" className="btn btn-primary px-3" disabled={sending || !text.trim()}>
            <i className="bi bi-send" />
          </button>
        </form>
      ) : (
        <div className="chat-input-bar justify-content-center text-muted small py-3">
          <i className="bi bi-lock me-2" />Chat is available once an officer is assigned.
        </div>
      )}

      {error && <div className="alert alert-danger m-3 mb-3 py-2">{error}</div>}
    </div>
  )
}
