import { useState, useEffect } from 'react'
import { listDepartments } from '../services/departmentService'
import { createComplaint } from '../services/complaintService'

const PRIORITIES = [
  { value: 'low', label: 'Low' },
  { value: 'medium', label: 'Medium' },
  { value: 'high', label: 'High' },
]

export function ComplaintForm({ onCreated }) {
  const [departments, setDepartments] = useState([])
  const [loadingDeps, setLoadingDeps] = useState(true)
  const [form, setForm] = useState({
    department_id: '',
    title: '',
    description: '',
    priority: 'medium',
    location: '',
  })
  const [attachments, setAttachments] = useState([])
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    listDepartments({ activeOnly: true })
      .then(setDepartments)
      .catch((e) => setError(e.message))
      .finally(() => setLoadingDeps(false))
  }, [])

  const onChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }))

  const onFileChange = (e) => {
    const files = Array.from(e.target.files || [])
    setAttachments(files)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (!form.department_id) return setError('Please select a department.')
    if (!form.title.trim() || !form.description.trim()) return setError('Title and description are required.')

    setSubmitting(true)
    try {
      const attachmentUrls = attachments.map((f) => `file:${f.name}`)
      const created = await createComplaint({
        department_id: form.department_id,
        title: form.title.trim(),
        description: form.description.trim(),
        priority: form.priority,
        location: form.location.trim() || null,
        attachments: attachmentUrls,
      })
      setForm({ department_id: '', title: '', description: '', priority: 'medium', location: '' })
      setAttachments([])
      const fileInput = document.getElementById('attachFiles')
      if (fileInput) fileInput.value = ''
      onCreated?.(created)
    } catch (err) {
      setError(err.message || 'Failed to submit complaint.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="card card-shadow border-0">
      <div className="card-header bg-white border-0 py-3">
        <h5 className="mb-0"><i className="bi bi-plus-circle me-2 text-primary" />File a New Complaint</h5>
      </div>
      <div className="card-body">
        {error && <div className="alert alert-danger py-2">{error}</div>}
        <div className="row g-3">
          <div className="col-md-6">
            <label className="form-label">Department <span className="text-danger">*</span></label>
            <select
              name="department_id"
              className="form-select"
              value={form.department_id}
              onChange={onChange}
              disabled={loadingDeps}
              required
            >
              <option value="">{loadingDeps ? 'Loading…' : 'Select department'}</option>
              {departments.map((d) => (
                <option key={d.id} value={d.id}>{d.name}</option>
              ))}
            </select>
          </div>
          <div className="col-md-6">
            <label className="form-label">Priority</label>
            <select name="priority" className="form-select" value={form.priority} onChange={onChange}>
              {PRIORITIES.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
          </div>
          <div className="col-12">
            <label className="form-label">Title <span className="text-danger">*</span></label>
            <input
              name="title"
              className="form-control"
              value={form.title}
              onChange={onChange}
              placeholder="Short summary of the issue"
              maxLength={120}
              required
            />
          </div>
          <div className="col-12">
            <label className="form-label">Description <span className="text-danger">*</span></label>
            <textarea
              name="description"
              className="form-control"
              rows={4}
              value={form.description}
              onChange={onChange}
              placeholder="Describe the issue in detail…"
              required
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Location <span className="text-muted small">(optional)</span></label>
            <input
              name="location"
              className="form-control"
              value={form.location}
              onChange={onChange}
              placeholder="Address / area / landmark"
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Attachments <span className="text-muted small">(optional)</span></label>
            <input
              id="attachFiles"
              type="file"
              className="form-control"
              multiple
              onChange={onFileChange}
            />
            <div className="form-text">Up to ~5 photos or documents.</div>
          </div>
        </div>
      </div>
      <div className="card-footer bg-white border-0 d-flex justify-content-end">
        <button type="submit" className="btn btn-primary px-4" disabled={submitting || loadingDeps}>
          {submitting ? (
            <><span className="spinner-border spinner-border-sm me-2" />Submitting…</>
          ) : (
            <><i className="bi bi-send me-2" />Submit Complaint</>
          )}
        </button>
      </div>
    </form>
  )
}
