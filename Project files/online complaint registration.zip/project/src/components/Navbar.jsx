import { Link, useNavigate, NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const DASHBOARD_LINK = {
  user: { to: '/user/dashboard', label: 'My Complaints' },
  officer: { to: '/officer/dashboard', label: 'Assigned Complaints' },
  admin: { to: '/admin/dashboard', label: 'Admin Console' },
}

export function Navbar() {
  const { isAuthenticated, profile, role, signOut } = useAuth()
  const navigate = useNavigate()

  const handleSignOut = async (e) => {
    e.preventDefault()
    await signOut()
    navigate('/login', { replace: true })
  }

  const dash = DASHBOARD_LINK[role]

  return (
    <nav className="navbar navbar-expand-lg sticky-top app-navbar shadow-sm">
      <div className="container">
        <Link to="/" className="navbar-brand d-flex align-items-center gap-2 fw-semibold">
          <span className="brand-mark">CR</span>
          <span className="brand-text">ComplaintRegister</span>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navMain"
          aria-controls="navMain"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>
        <div className="collapse navbar-collapse" id="navMain">
          <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-1">
            <li className="nav-item">
              <NavLink to="/" end className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
                Home
              </NavLink>
            </li>
            {isAuthenticated && dash && (
              <li className="nav-item">
                <NavLink to={dash.to} className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
                  {dash.label}
                </NavLink>
              </li>
            )}
            {!isAuthenticated && (
              <>
                <li className="nav-item">
                  <NavLink to="/login" className={({ isActive }) => `nav-link${isActive ? ' active' : ''}`}>
                    Login
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink to="/register" className="btn btn-light ms-lg-2 px-3">
                    Register
                  </NavLink>
                </li>
              </>
            )}
            {isAuthenticated && (
              <li className="nav-item dropdown">
                <button
                  className="btn btn-link nav-link d-flex align-items-center gap-2 dropdown-toggle text-decoration-none"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                  <span className="avatar-circle text-uppercase">
                    {(profile?.full_name || profile?.email || 'U').slice(0, 1)}
                  </span>
                  <span className="d-none d-lg-inline small">
                    {profile?.full_name || 'User'}
                    <span className="badge text-bg-secondary ms-1 text-capitalize">{role}</span>
                  </span>
                </button>
                <ul className="dropdown-menu dropdown-menu-end shadow-sm">
                  <li><span className="dropdown-item-text small text-muted">Signed in as<br /><strong>{profile?.email || ''}</strong></span></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button className="dropdown-item text-danger" onClick={handleSignOut}>
                      <i className="bi bi-box-arrow-right me-2" />Sign out
                    </button>
                  </li>
                </ul>
              </li>
            )}
          </ul>
        </div>
      </div>
    </nav>
  )
}
