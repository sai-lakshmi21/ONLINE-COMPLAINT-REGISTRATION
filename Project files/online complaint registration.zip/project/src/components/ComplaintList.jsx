import { Link } from 'react-router-dom'
import { StatusBadge, PriorityBadge } from './StatusBadge'

function formatDate(iso) {
  if (!iso) return '—'
  const d = new Date(iso)
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
}

export function ComplaintList({ complaints, emptyText = 'No complaints yet.', showUser = false, showOfficer = false }) {
  if (!complaints || complaints.length === 0) {
    return (
      <div className="alert alert-light border text-center text-muted py-4 mb-0">
        <i className="bi bi-inbox fs-3 d-block mb-2 opacity-50" />
        {emptyText}
      </div>
    )
  }

  return (
    <div className="table-responsive">
      <table className="table table-hover align-middle complaint-table mb-0">
        <thead>
          <tr>
            <th>Title</th>
            <th>Department</th>
            <th>Priority</th>
            <th>Status</th>
            {showUser && <th>Raised by</th>}
            {showOfficer && <th>Assigned to</th>}
            <th>Created</th>
          </tr>
        </thead>
        <tbody>
          {complaints.map((c) => (
            <tr key={c.id}>
              <td>
                <Link to={`/complaints/${c.id}`} className="text-decoration-none fw-medium">
                  {c.title}
                </Link>
                {c.location && (
                  <div className="small text-muted">
                    <i className="bi bi-geo-alt" /> {c.location}
                  </div>
                )}
              </td>
              <td>{c.department?.name || '—'}</td>
              <td><PriorityBadge priority={c.priority} /></td>
              <td><StatusBadge status={c.status} /></td>
              {showUser && <td className="small">{c.user?.full_name || '—'}</td>}
              {showOfficer && (
                <td className="small">
                  {c.officer ? c.officer.full_name : <span className="text-muted fst-italic">Unassigned</span>}
                </td>
              )}
              <td className="small text-muted">{formatDate(c.created_at)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
