const MAP = {
  pending: { label: 'Pending', cls: 'bg-warning-subtle text-warning-emphasis border-warning-subtle' },
  in_progress: { label: 'In Progress', cls: 'bg-info-subtle text-info-emphasis border-info-subtle' },
  resolved: { label: 'Resolved', cls: 'bg-success-subtle text-success-emphasis border-success-subtle' },
}

const PRIORITY = {
  low: 'bg-secondary-subtle text-secondary-emphasis',
  medium: 'bg-warning-subtle text-warning-emphasis',
  high: 'bg-danger-subtle text-danger-emphasis',
}

export function StatusBadge({ status }) {
  const s = MAP[status] || MAP.pending
  return <span className={`badge rounded-pill border ${s.cls}`}>{s.label}</span>
}

export function PriorityBadge({ priority }) {
  const cls = PRIORITY[priority] || PRIORITY.medium
  return (
    <span className={`badge rounded-pill text-capitalize ${cls}`}>
      {priority}
    </span>
  )
}
