import { useEffect, useState } from 'react'
import { listOfficers } from '../services/adminService'

export function AssignOfficerSelect({ complaint, onAssign }) {
  const [officers, setOfficers] = useState([])
  const [value, setValue] = useState(complaint?.officer_id || '')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    listOfficers()
      .then(setOfficers)
      .catch(() => setOfficers([]))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    setValue(complaint?.officer_id || '')
  }, [complaint?.officer_id])

  const handleChange = async (e) => {
    const v = e.target.value
    setValue(v)
    setSaving(true)
    try {
      await onAssign(v || null)
    } catch (err) {
      alert(err.message || 'Failed to assign officer.')
      setValue(complaint?.officer_id || '')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="input-group input-group-sm">
      <span className="input-group-text bg-light">
        {saving ? <span className="spinner-border spinner-border-sm" /> : <i className="bi bi-person-badge" />}
      </span>
      <select
        className="form-select"
        value={value || ''}
        onChange={handleChange}
        disabled={loading || saving}
      >
        <option value="">Unassigned</option>
        {officers.map((o) => (
          <option key={o.id} value={o.id}>{o.full_name}</option>
        ))}
      </select>
    </div>
  )
}
