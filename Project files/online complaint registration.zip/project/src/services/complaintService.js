import { supabase } from '../lib/supabaseClient'

const FULL_SELECT = `
  id, title, description, priority, location, status, notes, attachments,
  created_at, updated_at,
  user_id, officer_id, department_id,
  user:user_id ( id, full_name, email ),
  officer:officer_id ( id, full_name, email ),
  department:department_id ( id, name )
`

export async function createComplaint({ department_id, title, description, priority, location, attachments }) {
  const { data, error } = await supabase
    .from('complaints')
    .insert({
      department_id,
      title,
      description,
      priority: priority || 'medium',
      location: location || null,
      attachments: attachments || [],
    })
    .select(FULL_SELECT)
    .single()
  if (error) throw error
  return data
}

export async function getMyComplaints() {
  const { data, error } = await supabase
    .from('complaints')
    .select(FULL_SELECT)
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}

export async function getAssignedComplaints() {
  const { data, error } = await supabase
    .from('complaints')
    .select(FULL_SELECT)
    .not('officer_id', 'is', null)
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}

export async function getAllComplaints() {
  const { data, error } = await supabase
    .from('complaints')
    .select(FULL_SELECT)
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}

export async function getComplaint(id) {
  const { data, error } = await supabase
    .from('complaints')
    .select(FULL_SELECT)
    .eq('id', id)
    .maybeSingle()
  if (error) throw error
  return data
}

export async function updateComplaintStatus(id, status, notes) {
  const patch = { status }
  if (notes !== undefined) patch.notes = notes
  const { data, error } = await supabase
    .from('complaints')
    .update(patch)
    .eq('id', id)
    .select(FULL_SELECT)
    .single()
  if (error) throw error
  return data
}

export async function assignOfficer(id, officerId) {
  const { data, error } = await supabase
    .from('complaints')
    .update({ officer_id: officerId || null })
    .eq('id', id)
    .select(FULL_SELECT)
    .single()
  if (error) throw error
  return data
}
