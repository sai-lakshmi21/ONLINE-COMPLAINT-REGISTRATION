import { supabase } from '../lib/supabaseClient'

export async function listUsers() {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, phone, address, role, is_active, created_at')
    .order('created_at', { ascending: false })
  if (error) throw error
  return data
}

export async function listOfficers() {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, email, role, is_active')
    .eq('role', 'officer')
    .eq('is_active', true)
    .order('full_name', { ascending: true })
  if (error) throw error
  return data
}

export async function promoteUser(userId, role) {
  const { error } = await supabase.rpc('promote_user', { target: userId, new_role: role })
  if (error) throw error
}

export async function getStats() {
  const { count: total, error: e1 } = await supabase
    .from('complaints')
    .select('*', { count: 'exact', head: true })
  if (e1) throw e1

  const { count: pending, error: e2 } = await supabase
    .from('complaints')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'pending')
  if (e2) throw e2

  const { count: inProgress, error: e3 } = await supabase
    .from('complaints')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'in_progress')
  if (e3) throw e3

  const { count: resolved, error: e4 } = await supabase
    .from('complaints')
    .select('*', { count: 'exact', head: true })
    .eq('status', 'resolved')
  if (e4) throw e4

  const { data: byDept, error: e5 } = await supabase
    .from('complaints')
    .select('department_id, department:department_id ( name )')
  if (e5) throw e5

  const deptCounts = {}
  for (const row of byDept || []) {
    const name = row.department?.name || 'Unknown'
    deptCounts[name] = (deptCounts[name] || 0) + 1
  }

  return { total, pending, inProgress, resolved, byDepartment: deptCounts }
}
