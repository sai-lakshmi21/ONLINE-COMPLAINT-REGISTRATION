import { supabase } from '../lib/supabaseClient'

export async function listDepartments({ activeOnly = true } = {}) {
  let query = supabase.from('departments').select('*').order('name', { ascending: true })
  if (activeOnly) query = query.eq('is_active', true)
  const { data, error } = await query
  if (error) throw error
  return data
}

export async function createDepartment({ name, description }) {
  const { data, error } = await supabase
    .from('departments')
    .insert({ name, description })
    .select()
    .single()
  if (error) throw error
  return data
}

export async function updateDepartment(id, patch) {
  const { data, error } = await supabase
    .from('departments')
    .update(patch)
    .eq('id', id)
    .select()
    .single()
  if (error) throw error
  return data
}

export async function toggleDepartment(id, isActive) {
  return updateDepartment(id, { is_active: isActive })
}
