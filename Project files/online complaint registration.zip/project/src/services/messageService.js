import { supabase } from '../lib/supabaseClient'

export async function getMessages(complaintId) {
  const { data, error } = await supabase
    .from('messages')
    .select(`
      id, text, created_at, sender_id,
      sender:sender_id ( id, full_name, role )
    `)
    .eq('complaint_id', complaintId)
    .order('created_at', { ascending: true })
  if (error) throw error
  return data
}

export async function sendMessage(complaintId, text) {
  const { data, error } = await supabase
    .from('messages')
    .insert({ complaint_id: complaintId, text })
    .select(`
      id, text, created_at, sender_id,
      sender:sender_id ( id, full_name, role )
    `)
    .single()
  if (error) throw error
  return data
}

export function subscribeToMessages(complaintId, onMessage) {
  const channel = supabase
    .channel(`messages:${complaintId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `complaint_id=eq.${complaintId}`,
      },
      (payload) => onMessage(payload.new)
    )
    .subscribe()
  return channel
}

export function subscribeToComplaint(complaintId, onChange) {
  const channel = supabase
    .channel(`complaint:${complaintId}`)
    .on(
      'postgres_changes',
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'complaints',
        filter: `id=eq.${complaintId}`,
      },
      (payload) => onChange(payload.new)
    )
    .subscribe()
  return channel
}

export function unsubscribeChannel(channel) {
  if (channel) supabase.removeChannel(channel)
}
