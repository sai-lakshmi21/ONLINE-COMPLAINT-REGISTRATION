import { useEffect, useState, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import { getAllComplaints } from '../services/complaintService'
import { listDepartments, createDepartment, toggleDepartment } from '../services/departmentService'
import { listUsers, promoteUser, getStats } from '../services/adminService'
import { ComplaintList } from '../components/ComplaintList'
import { Spinner } from '../components/Spinner'

const TABS = [
  { id: 'complaints', label: 'Complaints', icon: 'bi-list-task' },
  { id: 'departments', label: 'Departments', icon: 'bi-diagram-3' },
  { id: 'users', label: 'Users & Officers', icon: 'bi-people' },
  { id: 'analytics', label: 'Analytics', icon: 'bi-bar-chart' },
]

export default function AdminDashboard() {
  const { profile, refreshProfile } = useAuth()
  const [tab, setTab] = useState('complaints')
  const [complaints, setComplaints] = useState([])
  const [departments, setDepartments] = useState([])
  const [users, setUsers] = useState([])
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  const loadAll = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const [c, d, u, s] = await Promise.all([getAllComplaints(), listDepartments({ activeOnly: false }), listUsers(), getStats()])
      setComplaints(c)
      setDepartments(d)
      setUsers(u)
      setStats(s)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { loadAll() }, [loadAll])

  const handleCreateDept = async (e) => {
    e.preventDefault()
    const form = e.target
    const name = form.name.value.trim()
    const description = form.description.value.trim()
    if (!name) return
    try {
      await createDepartment({ name, description })
      form.reset()
      setDepartments(await listDepartments({ activeOnly: false }))
    } catch (err) {
      alert(err.message)
    }
  }

  const handleToggleDept = async (id, isActive) => {
    try {
      await toggleDepartment(id, isActive)
      setDepartments(await listDepartments({ activeOnly: false }))
    } catch (err) {
      alert(err.message)
    }
  }

  const handlePromote = async (userId, newRole) => {
    try {
      await promoteUser(userId, newRole)
      setUsers(await listUsers())
      if (userId === profile?.id) await refreshProfile()
    } catch (err) {
      alert(err.message)
    }
  }

  return (
    <div className="container py-4 py-md-5">
      <div className="mb-4">
        <h1 className="h3 fw-bold mb-1">Admin Console</h1>
        <p className="text-muted mb-0">Manage departments, officers, and assignments. View all complaints and analytics.</p>
      </div>

      {error && <div className="alert alert-danger">{error}</div>}

      <ul className="nav nav-pills gap-2 mb-4">
        {TABS.map((t) => (
          <li className="nav-item" key={t.id}>
            <button className={`nav-link ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>
              <i className={`bi ${t.icon} me-2`} />{t.label}
            </button>
          </li>
        ))}
      </ul>

      {loading ? <Spinner /> : (
        <>
          {tab === 'complaints' && (
            <div className="card card-shadow border-0">
              <div className="card-header bg-white border-0 py-3 d-flex justify-content-between">
                <h5 className="mb-0">All Complaints ({complaints.length})</h5>
              </div>
              <div className="card-body p-0">
                <ComplaintList complaints={complaints} showUser showOfficer emptyText="No complaints in the system yet." />
              </div>
            </div>
          )}

          {tab === 'departments' && (
            <div className="row g-4">
              <div className="col-lg-7">
                <div className="card card-shadow border-0">
                  <div className="card-header bg-white border-0 py-3"><h5 className="mb-0">Departments</h5></div>
                  <ul className="list-group list-group-flush">
                    {departments.map((d) => (
                      <li key={d.id} className="list-group-item d-flex justify-content-between align-items-start">
                        <div>
                          <div className="fw-semibold">{d.name} {!d.is_active && <span className="badge text-bg-secondary ms-1">inactive</span>}</div>
                          {d.description && <div className="small text-muted">{d.description}</div>}
                        </div>
                        <div className="form-check form-switch">
                          <input className="form-check-input" type="checkbox" checked={d.is_active} onChange={(e) => handleToggleDept(d.id, e.target.checked)} />
                        </div>
                      </li>
                    ))}
                    {departments.length === 0 && <li className="list-group-item text-muted">No departments.</li>}
                  </ul>
                </div>
              </div>
              <div className="col-lg-5">
                <div className="card card-shadow border-0">
                  <div className="card-header bg-white border-0 py-3"><h5 className="mb-0">Add Department</h5></div>
                  <div className="card-body">
                    <form onSubmit={handleCreateDept}>
                      <div className="mb-3">
                        <label className="form-label">Name</label>
                        <input name="name" className="form-control" required />
                      </div>
                      <div className="mb-3">
                        <label className="form-label">Description</label>
                        <textarea name="description" className="form-control" rows={3} />
                      </div>
                      <button className="btn btn-primary w-100" type="submit"><i className="bi bi-plus-lg me-2" />Add</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          )}

          {tab === 'users' && (
            <div className="card card-shadow border-0">
              <div className="card-header bg-white border-0 py-3"><h5 className="mb-0">Users & Officers</h5></div>
              <div className="card-body p-0">
                <div className="table-responsive">
                  <table className="table table-hover align-middle mb-0">
                    <thead>
                      <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Change role</th>
                      </tr>
                    </thead>
                    <tbody>
                      {users.map((u) => (
                        <tr key={u.id}>
                          <td>{u.full_name}</td>
                          <td className="small text-muted">{u.phone || '—'}</td>
                          <td><span className="badge text-bg-secondary text-capitalize">{u.role}</span></td>
                          <td>{u.is_active ? <span className="badge text-bg-success">active</span> : <span className="badge text-bg-secondary">inactive</span>}</td>
                          <td>
                            <select
                              className="form-select form-select-sm"
                              value={u.role}
                              onChange={(e) => handlePromote(u.id, e.target.value)}
                              disabled={u.id === profile?.id}
                            >
                              <option value="user">user</option>
                              <option value="officer">officer</option>
                              <option value="admin">admin</option>
                            </select>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {tab === 'analytics' && stats && (
            <div className="row g-4">
              <div className="col-md-3"><StatCard label="Total" value={stats.total} icon="bi-collection" cls="text-primary" /></div>
              <div className="col-md-3"><StatCard label="Pending" value={stats.pending} icon="bi-clock" cls="text-warning" /></div>
              <div className="col-md-3"><StatCard label="In Progress" value={stats.inProgress} icon="bi-hourglass-split" cls="text-info" /></div>
              <div className="col-md-3"><StatCard label="Resolved" value={stats.resolved} icon="bi-check2-circle" cls="text-success" /></div>
              <div className="col-12">
                <div className="card card-shadow border-0">
                  <div className="card-header bg-white border-0 py-3"><h5 className="mb-0">Complaints by Department</h5></div>
                  <div className="card-body">
                    {Object.keys(stats.byDepartment).length === 0 ? (
                      <p className="text-muted">No data yet.</p>
                    ) : (
                      <ul className="list-group list-group-flush">
                        {Object.entries(stats.byDepartment).map(([name, count]) => {
                          const max = Math.max(...Object.values(stats.byDepartment))
                          const pct = Math.round((count / max) * 100)
                          return (
                            <li key={name} className="list-group-item px-0">
                              <div className="d-flex justify-content-between">
                                <span>{name}</span>
                                <strong>{count}</strong>
                              </div>
                              <div className="progress mt-1" style={{ height: '6px' }}>
                                <div className="progress-bar bg-primary" style={{ width: `${pct}%` }} />
                              </div>
                            </li>
                          )
                        })}
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}

function StatCard({ label, value, icon, cls }) {
  return (
    <div className="card card-shadow border-0 h-100">
      <div className="card-body d-flex align-items-center gap-3">
        <div className={`stat-icon ${cls}`}><i className={`bi ${icon}`} /></div>
        <div>
          <div className="h4 mb-0 fw-bold">{value ?? 0}</div>
          <div className="text-muted small">{label}</div>
        </div>
      </div>
    </div>
  )
}
