import { useEffect, useState, useCallback } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { getComplaint, updateComplaintStatus, assignOfficer } from '../services/complaintService'
import { subscribeToComplaint, unsubscribeChannel } from '../services/messageService'
import { StatusBadge, PriorityBadge } from '../components/StatusBadge'
import { AssignOfficerSelect } from '../components/AssignOfficerSelect'
import { ChatComponent } from '../components/ChatComponent'
import { Spinner } from '../components/Spinner'

const STATUS_OPTIONS = [
  { value: 'pending', label: 'Pending' },
  { value: 'in_progress', label: 'In Progress' },
  { value: 'resolved', label: 'Resolved' },
]

function formatDate(iso) {
  if (!iso) return '—'
  return new Date(iso).toLocaleString(undefined, { dateStyle: 'long', timeStyle: 'short' })
}

export default function ComplaintDetailPage() {
  const { id } = useParams()
  const { user, role } = useAuth()
  const [complaint, setComplaint] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [savingStatus, setSavingStatus] = useState(false)
  const [notes, setNotes] = useState('')

  const load = useCallback(async () => {
    try {
      const data = await getComplaint(id)
      if (!data) {
        setError('Complaint not found, or you do not have access to it.')
        setComplaint(null)
      } else {
        setComplaint(data)
        setNotes(data.notes || '')
      }
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [id])

  useEffect(() => { load() }, [load])

  // Live update of complaint (status / assignment) via Realtime.
  useEffect(() => {
    const channel = subscribeToComplaint(id, () => { load() })
    return () => { unsubscribeChannel(channel) }
  }, [id, load])

  const handleStatusChange = async (e) => {
    const status = e.target.value
    setSavingStatus(true)
    try {
      const updated = await updateComplaintStatus(id, status, notes)
      setComplaint(updated)
    } catch (err) {
      alert(err.message)
    } finally {
      setSavingStatus(false)
    }
  }

  const handleSaveNotes = async () => {
    setSavingStatus(true)
    try {
      const updated = await updateComplaintStatus(id, complaint.status, notes)
      setComplaint(updated)
    } catch (err) {
      alert(err.message)
    } finally {
      setSavingStatus(false)
    }
  }

  const handleAssign = async (officerId) => {
    const updated = await assignOfficer(id, officerId)
    setComplaint(updated)
  }

  if (loading) return <div className="container py-5"><Spinner /></div>
  if (error) return (
    <div className="container py-5">
      <div className="alert alert-danger">{error}</div>
      <Link to={-1} className="btn btn-outline-secondary">Go back</Link>
    </div>
  )
  if (!complaint) return null

  const isOwner = complaint.user_id === user.id
  const isAssignedOfficer = complaint.officer_id === user.id
  const isAdmin = role === 'admin'
  const canManage = isAssignedOfficer || isAdmin
  const canChat = isOwner || isAssignedOfficer || isAdmin
  const hasOfficer = !!complaint.officer_id

  return (
    <div className="container py-4 py-md-5">
      <Link to={-1} className="text-decoration-none small text-muted mb-3 d-inline-block">
        <i className="bi bi-arrow-left me-1" />Back
      </Link>

      <div className="row g-4">
        <div className="col-lg-7">
          <div className="card card-shadow border-0 mb-4">
            <div className="card-body p-4">
              <div className="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">
                <div>
                  <h2 className="h4 fw-bold mb-1">{complaint.title}</h2>
                  <div className="text-muted small">
                    Filed {formatDate(complaint.created_at)} in <strong>{complaint.department?.name}</strong>
                  </div>
                </div>
                <div className="d-flex flex-wrap gap-2">
                  <StatusBadge status={complaint.status} />
                  <PriorityBadge priority={complaint.priority} />
                </div>
              </div>

              <dl className="row mb-0 small">
                <dt className="col-sm-3 text-muted">Description</dt>
                <dd className="col-sm-9"><p className="mb-2">{complaint.description}</p></dd>

                <dt className="col-sm-3 text-muted">Location</dt>
                <dd className="col-sm-9">{complaint.location || '—'}</dd>

                <dt className="col-sm-3 text-muted">Raised by</dt>
                <dd className="col-sm-9">{complaint.user?.full_name || '—'}</dd>

                <dt className="col-sm-3 text-muted">Assigned officer</dt>
                <dd className="col-sm-9">
                  {complaint.officer ? complaint.officer.full_name : <span className="text-muted fst-italic">Unassigned</span>}
                  {isAdmin && <div className="mt-2"><AssignOfficerSelect complaint={complaint} onAssign={handleAssign} /></div>}
                </dd>

                {complaint.attachments?.length > 0 && (
                  <>
                    <dt className="col-sm-3 text-muted">Attachments</dt>
                    <dd className="col-sm-9">
                      <ul className="list-unstyled mb-0">
                        {complaint.attachments.map((a, i) => (
                          <li key={i} className="small"><i className="bi bi-paperclip me-1" />{a.replace(/^file:/, '')}</li>
                        ))}
                      </ul>
                    </dd>
                  </>
                )}
              </dl>
            </div>
          </div>

          {canManage && (
            <div className="card card-shadow border-0 mb-4">
              <div className="card-header bg-white border-0 py-3"><h5 className="mb-0">Officer / Admin Controls</h5></div>
              <div className="card-body">
                <div className="row g-3 align-items-end">
                  <div className="col-md-5">
                    <label className="form-label">Update status</label>
                    <div className="input-group">
                      <select className="form-select" value={complaint.status} onChange={handleStatusChange} disabled={savingStatus}>
                        {STATUS_OPTIONS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                      </select>
                      {savingStatus && <span className="input-group-text"><span className="spinner-border spinner-border-sm" /></span>}
                    </div>
                  </div>
                  <div className="col-md-7">
                    <label className="form-label">Internal notes</label>
                    <textarea className="form-control" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Visible to officers and admins only" />
                  </div>
                  <div className="col-12 d-flex justify-content-end">
                    <button className="btn btn-outline-primary btn-sm" onClick={handleSaveNotes} disabled={savingStatus}>
                      <i className="bi bi-save me-1" />Save notes
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {complaint.notes && (
            <div className="card border-0 bg-light">
              <div className="card-body small">
                <strong>Internal notes:</strong> {complaint.notes}
              </div>
            </div>
          )}
        </div>

        <div className="col-lg-5">
          {hasOfficer || isAdmin ? (
            <ChatComponent complaintId={id} canChat={canChat} />
          ) : (
            <div className="card card-shadow border-0">
              <div className="card-body text-center py-5 text-muted">
                <i className="bi bi-chat fs-3 d-block mb-2 opacity-50" />
                <p className="mb-0">Chat will be available once an admin assigns an officer to this complaint.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
