import { useEffect, useState, useCallback } from 'react'
import { useAuth } from '../context/AuthContext'
import { getMyComplaints } from '../services/complaintService'
import { ComplaintList } from '../components/ComplaintList'
import { ComplaintForm } from '../components/ComplaintForm'
import { Spinner } from '../components/Spinner'

export default function UserDashboard() {
  const { profile } = useAuth()
  const [complaints, setComplaints] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [filter, setFilter] = useState('all')
  const [showForm, setShowForm] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await getMyComplaints()
      setComplaints(data)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { load() }, [load])

  const onCreated = () => {
    setShowForm(false)
    load()
  }

  const counts = complaints.reduce((acc, c) => {
    acc[c.status] = (acc[c.status] || 0) + 1
    return acc
  }, {})
  const visible = filter === 'all' ? complaints : complaints.filter((c) => c.status === filter)

  return (
    <div className="container py-4 py-md-5">
      <div className="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div>
          <h1 className="h3 fw-bold mb-1">Hello, {profile?.full_name?.split(' ')[0] || 'there'} 👋</h1>
          <p className="text-muted mb-0">Track your complaints and chat with officers in real time.</p>
        </div>
        <button className="btn btn-primary px-4" onClick={() => setShowForm((s) => !s)}>
          <i className={`bi ${showForm ? 'bi-x-lg' : 'bi-plus-lg'} me-2`} />{showForm ? 'Cancel' : 'New Complaint'}
        </button>
      </div>

      {showForm && (
        <div className="mb-4">
          <ComplaintForm onCreated={onCreated} />
        </div>
      )}

      <div className="row g-3 mb-4">
        <StatCard label="Total" value={complaints.length} icon="bi-collection" cls="text-primary" />
        <StatCard label="Pending" value={counts.pending || 0} icon="bi-clock" cls="text-warning" />
        <StatCard label="In Progress" value={counts.in_progress || 0} icon="bi-hourglass-split" cls="text-info" />
        <StatCard label="Resolved" value={counts.resolved || 0} icon="bi-check2-circle" cls="text-success" />
      </div>

      <div className="card card-shadow border-0">
        <div className="card-header bg-white border-0 d-flex flex-wrap align-items-center justify-content-between gap-2 py-3">
          <h5 className="mb-0">My Complaints</h5>
          <div className="btn-group btn-group-sm" role="group" aria-label="Filter by status">
            {['all', 'pending', 'in_progress', 'resolved'].map((f) => (
              <button
                key={f}
                type="button"
                className={`btn ${filter === f ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setFilter(f)}
              >
                {f === 'all' ? 'All' : f.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>
        <div className="card-body p-0">
          {loading ? <Spinner /> : error ? <div className="alert alert-danger m-3">{error}</div> : <ComplaintList complaints={visible} emptyText="You haven’t filed any complaints yet. Click “New Complaint” to get started." />}
        </div>
      </div>
    </div>
  )
}

function StatCard({ label, value, icon, cls }) {
  return (
    <div className="col-6 col-lg-3">
      <div className="card card-shadow border-0 h-100">
        <div className="card-body d-flex align-items-center gap-3">
          <div className={`stat-icon ${cls}`}><i className={`bi ${icon}`} /></div>
          <div>
            <div className="h4 mb-0 fw-bold">{value}</div>
            <div className="text-muted small text-capitalize">{label}</div>
          </div>
        </div>
      </div>
    </div>
  )
}
