import { useState } from 'react'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

const HOME_BY_ROLE = { user: '/user/dashboard', officer: '/officer/dashboard', admin: '/admin/dashboard' }

export default function LoginPage() {
  const { signIn } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const from = location.state?.from?.pathname

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const { profile } = await signIn(email.trim(), password)
      const role = profile?.role
      const dest = from || HOME_BY_ROLE[role] || '/user/dashboard'
      navigate(dest, { replace: true })
    } catch (err) {
      setError(err.message || 'Invalid email or password.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-7 col-lg-5">
          <div className="card card-shadow border-0">
            <div className="card-body p-4 p-md-5">
              <h2 className="fw-bold mb-1">Welcome back</h2>
              <p className="text-muted mb-4">Sign in to continue to ComplaintRegister.</p>

              {error && <div className="alert alert-danger py-2">{error}</div>}

              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control form-control-lg"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    autoComplete="email"
                    required
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Password</label>
                  <input
                    type="password"
                    className="form-control form-control-lg"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="current-password"
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary btn-lg w-100" disabled={loading}>
                  {loading ? (<><span className="spinner-border spinner-border-sm me-2" />Signing in…</>) : 'Sign in'}
                </button>
              </form>

              <p className="text-center text-muted mt-4 mb-0">
                Don’t have an account? <Link to="/register">Register as a citizen</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
