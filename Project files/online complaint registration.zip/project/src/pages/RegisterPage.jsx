import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function RegisterPage() {
  const { signUp } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ full_name: '', email: '', phone: '', address: '', password: '', confirm: '' })
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const onChange = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    if (form.password.length < 6) return setError('Password must be at least 6 characters.')
    if (form.password !== form.confirm) return setError('Passwords do not match.')

    setLoading(true)
    try {
      await signUp({
        full_name: form.full_name.trim(),
        email: form.email.trim(),
        password: form.password,
        phone: form.phone.trim(),
        address: form.address.trim(),
      })
      navigate('/user/dashboard', { replace: true })
    } catch (err) {
      setError(err.message || 'Registration failed.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container py-5">
      <div className="row justify-content-center">
        <div className="col-md-8 col-lg-6">
          <div className="card card-shadow border-0">
            <div className="card-body p-4 p-md-5">
              <h2 className="fw-bold mb-1">Create your account</h2>
              <p className="text-muted mb-4">Register as a citizen to file and track complaints.</p>

              {error && <div className="alert alert-danger py-2">{error}</div>}

              <form onSubmit={handleSubmit}>
                <div className="row g-3">
                  <div className="col-12">
                    <label className="form-label">Full name</label>
                    <input name="full_name" className="form-control form-control-lg" value={form.full_name} onChange={onChange} required />
                  </div>
                  <div className="col-md-7">
                    <label className="form-label">Email</label>
                    <input type="email" name="email" className="form-control form-control-lg" value={form.email} onChange={onChange} required />
                  </div>
                  <div className="col-md-5">
                    <label className="form-label">Phone <span className="text-muted small">(optional)</span></label>
                    <input name="phone" className="form-control form-control-lg" value={form.phone} onChange={onChange} />
                  </div>
                  <div className="col-12">
                    <label className="form-label">Address <span className="text-muted small">(optional)</span></label>
                    <input name="address" className="form-control form-control-lg" value={form.address} onChange={onChange} />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Password</label>
                    <input type="password" name="password" className="form-control form-control-lg" value={form.password} onChange={onChange} required />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Confirm password</label>
                    <input type="password" name="confirm" className="form-control form-control-lg" value={form.confirm} onChange={onChange} required />
                  </div>
                </div>
                <button type="submit" className="btn btn-primary btn-lg w-100 mt-4" disabled={loading}>
                  {loading ? (<><span className="spinner-border spinner-border-sm me-2" />Creating account…</>) : 'Create account'}
                </button>
              </form>

              <p className="text-center text-muted mt-4 mb-0">
                Already registered? <Link to="/login">Sign in</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
