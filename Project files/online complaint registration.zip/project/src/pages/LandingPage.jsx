import { Link } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

export default function LandingPage() {
  const { isAuthenticated, role } = useAuth()
  const dash = { user: '/user/dashboard', officer: '/officer/dashboard', admin: '/admin/dashboard' }[role]
  const primaryCta = isAuthenticated && dash ? { to: dash, label: 'Go to your dashboard' } : { to: '/register', label: 'Get started — it’s free' }

  return (
    <div className="landing-hero">
      <div className="container py-5">
        <div className="row align-items-center g-5 min-vh-75 py-md-4">
          <div className="col-lg-6">
            <span className="badge rounded-pill text-bg-light-subtle border mb-3 px-3 py-2">
              <i className="bi bi-shield-check me-2" />Gov-grade complaint tracking
            </span>
            <h1 className="display-4 fw-bold mb-3 lh-sm">
              Raise, track & resolve<br />civic complaints in real time.
            </h1>
            <p className="lead text-secondary mb-4">
              ComplaintRegister connects citizens, officers, and administrators on one
              platform. File a complaint, chat with the assigned officer live, and follow
              it through to resolution — transparent, accountable, fast.
            </p>
            <div className="d-flex flex-wrap gap-2">
              <Link to={primaryCta.to} className="btn btn-primary btn-lg px-4">
                {primaryCta.label} <i className="bi bi-arrow-right ms-2" />
              </Link>
              {!isAuthenticated && (
                <Link to="/login" className="btn btn-outline-primary btn-lg px-4">
                  I already have an account
                </Link>
              )}
            </div>
            <div className="d-flex flex-wrap gap-4 mt-4 text-muted small">
              <span><i className="bi bi-check2-circle text-success me-1" />Real-time chat</span>
              <span><i className="bi bi-check2-circle text-success me-1" />Three role dashboards</span>
              <span><i className="bi bi-check2-circle text-success me-1" />Status tracking</span>
            </div>
          </div>
          <div className="col-lg-6">
            <div className="hero-card card card-shadow border-0 p-3">
              <div className="card-body p-3 p-md-4">
                <div className="d-flex align-items-center justify-content-between mb-3">
                  <span className="fw-semibold">Complaint #CR-2048</span>
                  <span className="badge rounded-pill text-bg-warning-subtle text-warning-emphasis">In Progress</span>
                </div>
                <div className="border-top pt-3">
                  <div className="d-flex gap-3 mb-2">
                    <div className="avatar-circle bg-primary-subtle text-primary-emphasis">U</div>
                    <div className="chat-bubble theirs">
                      <div className="chat-meta"><strong>You</strong></div>
                      <div className="chat-text">Streetlight near 4th Ave has been out for a week.</div>
                      <div className="chat-time">Today, 09:21</div>
                    </div>
                  </div>
                  <div className="d-flex gap-3 justify-content-end mb-3">
                    <div className="chat-bubble mine">
                      <div className="chat-meta"><strong>Officer Maya</strong> <span className="badge text-bg-info ms-1">Officer</span></div>
                      <div className="chat-text">Thanks — crew dispatched this morning. Should be fixed by 6pm.</div>
                      <div className="chat-time">Today, 10:02</div>
                    </div>
                    <div className="avatar-circle bg-info-subtle text-info-emphasis">M</div>
                  </div>
                  <div className="input-group">
                    <input className="form-control" placeholder="Type a message…" disabled />
                    <button className="btn btn-primary" disabled><i className="bi bi-send" /></button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
