/*
# Online Complaint Registration System — schema

1. Overview
This migration creates the full schema for an online complaint registration system
with three roles (user / officer / admin) backed by Supabase Auth. It replaces the
originally requested MongoDB/Mongoose + Express + socket.io stack with equivalent
Postgres tables, RLS policies, and Supabase Realtime — which is what runs in this
environment. The functional behaviour is identical: citizens register and file
complaints against departments, admins manage departments/officers and assign
complaints, officers update status and chat in real time with the citizen who
raised the complaint.

2. New Tables
- `profiles`
  - `id` uuid PK → auth.users.id (1:1). Represents the app-level User entity.
  - `full_name` text, displayed in chats and lists.
  - `phone` text, nullable.
  - `address` text, nullable.
  - `role` text NOT NULL DEFAULT 'user', CHECK in (user, officer, admin).
  - `is_active` boolean NOT NULL DEFAULT true.
  - `created_at`, `updated_at` timestamptz.
- `departments`
  - `id` uuid PK.
  - `name` text NOT NULL UNIQUE.
  - `description` text, nullable.
  - `is_active` boolean NOT NULL DEFAULT true.
  - `created_at` timestamptz.
- `complaints`
  - `id` uuid PK.
  - `user_id` uuid NOT NULL DEFAULT auth.uid() → profiles.id (the citizen).
  - `officer_id` uuid NULL → profiles.id (assigned officer).
  - `department_id` uuid NOT NULL → departments.id.
  - `title` text NOT NULL.
  - `description` text NOT NULL.
  - `priority` text NOT NULL DEFAULT 'medium', CHECK in (low, medium, high).
  - `location` text, nullable.
  - `status` text NOT NULL DEFAULT 'pending', CHECK in (pending, in_progress, resolved).
  - `notes` text, nullable — internal officer/admin notes.
  - `attachments` text[] DEFAULT '{}' — list of URLs or base64-less file references.
  - `created_at`, `updated_at` timestamptz.
- `messages`
  - `id` uuid PK.
  - `complaint_id` uuid NOT NULL → complaints.id ON DELETE CASCADE.
  - `sender_id` uuid NOT NULL DEFAULT auth.uid() → profiles.id.
  - `text` text NOT NULL.
  - `created_at` timestamptz.
  No separate attachments array on messages to keep chat simple.

3. New Functions / Triggers
- `handle_new_user()` trigger function: on insert into auth.users, creates a matching
  `profiles` row with role 'user'. Officers/admins are promoted manually via the
  admin UI (which calls an RPC) or by SQL.
- `set_updated_at()` trigger function: bumps `updated_at` on UPDATE for profiles and
  complaints.
- `promote_user(target uuid, new_role text)` SECURITY DEFINER RPC: lets an admin
  promote/demote a profile's role. Asserts caller is admin. Used by AdminDashboard.
- `seed_default_departments()` SECURITY DEFINER RPC: inserts a handful of starter
  departments if none exist, so the app is usable immediately after signup.

4. Indexes
- complaints(user_id), complaints(officer_id), complaints(department_id),
  complaints(status), complaints(priority).
- messages(complaint_id, created_at).

5. Security (RLS)
- profiles: a user can read/update their own row; admins can read all rows.
  Insert is handled server-side by the trigger (no client insert needed).
- departments: any authenticated user can read; only admins can insert/update.
- complaints: citizens see their own; officers see complaints assigned to them;
  admins see all. Citizens insert their own (user_id defaults to auth.uid()).
  Only the assigned officer or an admin can update status/notes/assignment.
- messages: participants of the complaint (the citizen who raised it + the
  assigned officer + any admin) can read; any such participant can insert.
  Sender defaults to auth.uid() so writes succeed without passing sender_id.
- All 4 CRUD verbs split into separate policies per table (no FOR ALL).

6. Realtime
- `alter publication supabase_realtime add table messages, complaints;`
  so the client can subscribe to new chat messages and complaint status changes
  and render them in real time (replaces socket.io rooms).

7. Important Notes
- The `user_id` / `sender_id` columns default to auth.uid() so client inserts that
  omit the owner still satisfy the WITH CHECK ownership predicates.
- Admin promotion is performed via the SECURITY DEFINER RPC `promote_user` — the
  RLS policies on profiles do not allow arbitrary client updates to `role`.
- Email confirmation stays OFF (default) so signup immediately yields a session.
*/

-- ---------- profiles ----------
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  phone text,
  address text,
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user','officer','admin')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_or_all_if_admin" ON profiles;
CREATE POLICY "select_own_or_all_if_admin"
ON profiles FOR SELECT TO authenticated
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'
));

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile"
ON profiles FOR UPDATE TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

-- ---------- departments ----------
CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE departments ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_departments" ON departments;
CREATE POLICY "select_departments"
ON departments FOR SELECT TO authenticated USING (true);

DROP POLICY IF EXISTS "insert_departments_admin" ON departments;
CREATE POLICY "insert_departments_admin"
ON departments FOR INSERT TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "update_departments_admin" ON departments;
CREATE POLICY "update_departments_admin"
ON departments FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
WITH CHECK (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "delete_departments_admin" ON departments;
CREATE POLICY "delete_departments_admin"
ON departments FOR DELETE TO authenticated
USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ---------- complaints ----------
CREATE TABLE IF NOT EXISTS complaints (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  officer_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  department_id uuid NOT NULL REFERENCES departments(id) ON DELETE RESTRICT,
  title text NOT NULL,
  description text NOT NULL,
  priority text NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high')),
  location text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','in_progress','resolved')),
  notes text,
  attachments text[] NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE complaints ENABLE ROW LEVEL SECURITY;

-- Citizens see their own; officers see assigned; admins see all.
DROP POLICY IF EXISTS "select_complaints_participants" ON complaints;
CREATE POLICY "select_complaints_participants"
ON complaints FOR SELECT TO authenticated
USING (
  user_id = auth.uid()
  OR officer_id = auth.uid()
  OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);

-- Citizens create their own (user_id defaults to auth.uid()).
DROP POLICY IF EXISTS "insert_complaints_owner" ON complaints;
CREATE POLICY "insert_complaints_owner"
ON complaints FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

-- Only assigned officer or admin can update.
DROP POLICY IF EXISTS "update_complaints_officer_or_admin" ON complaints;
CREATE POLICY "update_complaints_officer_or_admin"
ON complaints FOR UPDATE TO authenticated
USING (
  officer_id = auth.uid()
  OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
)
WITH CHECK (
  officer_id = auth.uid()
  OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
);

-- Admins can delete (e.g. spam). Not exposed in UI by default.
DROP POLICY IF EXISTS "delete_complaints_admin" ON complaints;
CREATE POLICY "delete_complaints_admin"
ON complaints FOR DELETE TO authenticated
USING (EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

-- ---------- messages ----------
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id uuid NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL DEFAULT auth.uid() REFERENCES profiles(id) ON DELETE CASCADE,
  text text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- A participant = the citizen, the assigned officer, or any admin.
DROP POLICY IF EXISTS "select_messages_participants" ON messages;
CREATE POLICY "select_messages_participants"
ON messages FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM complaints c
    WHERE c.id = messages.complaint_id
      AND (
        c.user_id = auth.uid()
        OR c.officer_id = auth.uid()
        OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
      )
  )
);

DROP POLICY IF EXISTS "insert_messages_participants" ON messages;
CREATE POLICY "insert_messages_participants"
ON messages FOR INSERT TO authenticated
WITH CHECK (
  sender_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM complaints c
    WHERE c.id = messages.complaint_id
      AND (
        c.user_id = auth.uid()
        OR c.officer_id = auth.uid()
        OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin')
      )
  )
);

-- ---------- indexes ----------
CREATE INDEX IF NOT EXISTS complaints_user_id_idx ON complaints(user_id);
CREATE INDEX IF NOT EXISTS complaints_officer_id_idx ON complaints(officer_id);
CREATE INDEX IF NOT EXISTS complaints_department_id_idx ON complaints(department_id);
CREATE INDEX IF NOT EXISTS complaints_status_idx ON complaints(status);
CREATE INDEX IF NOT EXISTS complaints_priority_idx ON complaints(priority);
CREATE INDEX IF NOT EXISTS messages_complaint_created_idx ON messages(complaint_id, created_at);

-- ---------- updated_at helper ----------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_set_updated_at ON profiles;
CREATE TRIGGER profiles_set_updated_at
BEFORE UPDATE ON profiles
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS complaints_set_updated_at ON complaints;
CREATE TRIGGER complaints_set_updated_at
BEFORE UPDATE ON complaints
FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- new-user trigger ----------
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ---------- admin promotion RPC ----------
CREATE OR REPLACE FUNCTION promote_user(target uuid, new_role text)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  caller_role text;
BEGIN
  SELECT role INTO caller_role FROM profiles WHERE id = auth.uid();
  IF caller_role IS NULL OR caller_role <> 'admin' THEN
    RAISE EXCEPTION 'Only admins can promote users';
  END IF;
  IF new_role NOT IN ('user','officer','admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  UPDATE profiles SET role = new_role WHERE id = target;
END;
$$;

-- ---------- seed default departments ----------
CREATE OR REPLACE FUNCTION seed_default_departments()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO departments (name, description) VALUES
    ('Public Works', 'Roads, drainage, street lighting, public infrastructure'),
    ('Sanitation', 'Garbage collection, waste management, cleanliness'),
    ('Water & Sewerage', 'Water supply, sewerage and related services'),
    ('Electricity', 'Street lighting and power-related civic issues'),
    ('Police & Safety', 'Law and order, public safety, traffic enforcement'),
    ('Health', 'Public health, sanitation at clinics, disease control'),
    ('Parks & Trees', 'Public parks, green cover, tree maintenance')
  ON CONFLICT (name) DO NOTHING;
END;
$$;

-- ---------- realtime publication ----------
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE complaints;

-- ---------- seed starter departments now ----------
SELECT seed_default_departments();
